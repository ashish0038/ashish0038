import React from 'react';

export const OppseError = () => (
    <h1>This is Oppse Error Page.</h1>
)
