import React from 'react';

export const Cart = () => (
    <h1>This is Cart.</h1>
)
