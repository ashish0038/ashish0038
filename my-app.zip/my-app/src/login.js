import React from 'react';
import {Row, Col, Form , Button} from 'react-bootstrap';
import './login.css';
import logo from './assests/logo.png';
export const Login = () => (
    <React.Fragment>
    <Row className="justify-content-md-center align-center-center">
        <Col sm={12} md={5} >
            <div className="login-from">
            <Form>
                <img className="login-logo" src={logo} alt={logo}/>
                <label className="login-label">It only takes a minute to login with P-Box.</label>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control type="email" placeholder="Enter email" />
                    <Form.Text className="text-muted">
                    We'll never share your email with anyone else.
                    </Form.Text>
                </Form.Group>

                <Form.Group controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control type="password" placeholder="Password" />
                </Form.Group>
                <Form.Group controlId="formBasicChecbox">
                    <Form.Check type="checkbox" label="Check me out" />
                </Form.Group>
                <div className="text-center">
                    <Button variant="primary" className="login-btn" type="submit">
                        Login
                    </Button>
                </div>
                </Form>
            </div>
        </Col>
    </Row>
    </React.Fragment>
)