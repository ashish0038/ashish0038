import React from 'react';
import './notifications.css';
import {Row, Col,Alert} from 'react-bootstrap';

class AlertDismissible extends React.Component {
    constructor(props) {
      super(props);
  
      this.state = { show: true };
    }
    
    render() {
      const handleHide = () => this.setState({ show: false });
      return (
        <>
          <Alert show={this.state.show} variant="light" onClose={handleHide} dismissible>
            <Alert.Heading>Notification Alert 1</Alert.Heading>
            <p>
              Duis mollis, est non commodo luctus, nisi erat porttitor ligula,
              eget lacinia odio sem nec elit. Cras mattis consectetur purus sit
              amet fermentum.
            </p>
            <hr />
            <div className="d-flex justify-content-start time">
              2 min ago
            </div>
          </Alert>
        </>
      );
    }
  }

export const Notifications = () => (
    <React.Fragment>
        <Row>
            <Col>
                <h2 className="app-title">Notifications</h2>
            </Col>
        </Row>
        <Row className="">
            <Col>
              <AlertDismissible />
            </Col>
        </Row>
        <Row className="">
            <Col>
              <AlertDismissible />
            </Col>
        </Row>
        <Row className="">
            <Col>
              <AlertDismissible />
            </Col>
        </Row>
        <Row className="">
            <Col>
              <AlertDismissible />
            </Col>
        </Row>
    </React.Fragment>
)