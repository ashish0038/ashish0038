import React from 'react';
import {Row, Col} from 'react-bootstrap';
import {Chart1} from './components/chart';
import {Chart2} from './components/chart';
import './home.css'
import dashboard from './assests/dashboard.png';
import products from './assests/products.png';
import users from './assests/users.png';
import transations from './assests/transations.png';
import report from './assests/report.png';
import notifications from './assests/notifications.png';




export const Home = (props) => (

    <React.Fragment>
        <div className="dashboard">
            <Row>
                <Col>
                    <h2 className="app-title">Dashboard</h2>
                </Col>
            </Row>
            <Row>
                <Col xs={12} md={2}>
                <div className="db-icon-box">
                        <div className="db-box">
                            <img className="db-icon" src={dashboard}  alt={dashboard}/>
                            <p className="icon-s-text">384</p>
                        </div>
                        <h1 className="db-title">Dashboard</h1>
                        <p className="db-sb-text">31 Updates</p>
                </div> 
                </Col>
                <Col xs={12} md={2}>
                <div className="db-icon-box">
                        <div className="db-box">
                            <img className="db-icon" src={products} alt={products}/>
                            <p className="icon-s-text">384</p>
                        </div>
                        <h1 className="db-title">Products</h1>
                        <p className="db-sb-text">19k Updates</p>
                </div> 
                </Col>
                <Col xs={12} md={2}>
                <div className="db-icon-box">
                        <div className="db-box">
                            <img className="db-icon" src={users} alt={users}/>
                            <p className="icon-s-text">384</p>
                        </div>
                        <h1 className="db-title">Users</h1>
                        <p className="db-sb-text">11 Active</p>
                </div> 
                </Col>
                <Col xs={12} md={2}>
                <div className="db-icon-box">
                        <div className="db-box">
                            <img className="db-icon" src={transations} alt={transations}/>
                            <p className="icon-s-text">384</p>
                        </div>
                        <h1 className="db-title">Transations</h1>
                        <p className="db-sb-text">3 Updates</p>
                </div> 
                </Col>
                <Col xs={12} md={2}>
                <div className="db-icon-box">
                        <div className="db-box">
                            <img className="db-icon" src={report} alt={report}/>
                            <p className="icon-s-text">384</p>
                        </div>
                        <h1 className="db-title">Reports</h1>
                        <p className="db-sb-text">10 Available</p>
                </div> 
                </Col>
                <Col xs={12} md={2}>
                <div className="db-icon-box">
                        <div className="db-box">
                            <img className="db-icon" src={notifications} alt={notifications}/>
                            <p className="icon-s-text">384</p>
                        </div>
                        <h1 className="db-title">Notifications</h1>
                        <p className="db-sb-text">28 Updates</p>
                </div> 
                </Col>
            </Row>
            <br/>
            <hr/>
            <Row>
                <Col>
                    <h2 className="app-title">Anlaysis Reports</h2>
                </Col>
            </Row>
            <Row>
                <Col md={6} sm={12}>
                    <Chart1/>
                    <p className="chart-title">Categories</p>
                </Col>
                <Col md={6} sm={12}>
                    <Chart2/>
                    <p className="chart-title">Transation</p>
                </Col>
            </Row>
        </div>
    </React.Fragment>
)
